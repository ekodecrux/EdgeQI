import { useState } from 'react';
import { ShieldCheck, ShieldAlert, Sparkles, AlertTriangle, RefreshCw, FileCode, CheckCircle2, HelpCircle } from 'lucide-react';
import { SecurityVulnerability } from '../types';

interface SecurityProps {
  vulnerabilities: SecurityVulnerability[];
  onApplyRemediation: (vulnerabilityId: string) => Promise<void>;
  isRemediating: string | null;
}

export default function SecurityTab({
  vulnerabilities,
  onApplyRemediation,
  isRemediating,
}: SecurityProps) {
  const [selectedVulId, setSelectedVulId] = useState<string | null>(vulnerabilities[0]?.id || null);

  const activeVul = vulnerabilities.find(v => v.id === selectedVulId) || vulnerabilities[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* 1. Vulnerability logs list */}
      <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-sm">
        <div>
          <h3 className="font-sans font-semibold text-lg text-slate-900 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            Security Scanning & Compliance Audits
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Identify SAST, DAST, SCA and container vulnerabilities. Trigger real-time remediation patches with Gemini models.
          </p>
        </div>

        {/* List of scanned bugs */}
        <div className="space-y-2 max-h-[360px] overflow-y-auto">
          {vulnerabilities.map((vul) => {
            const isSelected = selectedVulId === vul.id;
            const isCrit = vul.severity === 'Critical';
            const isHigh = vul.severity === 'High';

            return (
              <div
                key={vul.id}
                onClick={() => setSelectedVulId(vul.id)}
                className={`border rounded-xl p-3 cursor-pointer select-none transition-all ${
                  isSelected 
                    ? 'bg-slate-50 border-rose-600 shadow-sm' 
                    : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-mono font-bold text-slate-400">{vul.id}</span>
                      <span className={`text-[8px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                        isCrit ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                        isHigh ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {vul.severity}
                      </span>
                      <span className="text-[8px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded">
                        {vul.type}
                      </span>
                    </div>
                    <h4 className="text-xs font-semibold text-slate-800 line-clamp-1">{vul.title}</h4>
                  </div>

                  <span className={`text-[9.5px] text-right font-mono font-bold px-1.5 py-0.5 rounded border ${
                    vul.status === 'Remediated' 
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-250' 
                      : 'bg-rose-50 text-rose-600 border-rose-200 animate-pulse'
                  }`}>
                    {vul.status === 'Remediated' ? 'Remediated' : 'Open'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Compliance Tags summary */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-3">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-550 font-bold block">Compliance Requirements Status</span>
          <div className="grid grid-cols-2 gap-2 text-xs text-slate-700">
            <div className="bg-white p-2 rounded-lg flex items-center justify-between border border-slate-200">
              <span className="text-slate-500 font-mono text-[11px]">PCI-DSS:</span>
              <span className="text-emerald-700 font-bold">100% compliant</span>
            </div>
            <div className="bg-white p-2 rounded-lg flex items-center justify-between border border-slate-200">
              <span className="text-slate-500 font-mono text-[11px]">SOC2 Typ-2:</span>
              <span className="text-emerald-700 font-bold">100% compliant</span>
            </div>
            <div className="bg-white p-2 rounded-lg flex items-center justify-between border border-slate-200">
              <span className="text-slate-500 font-mono text-[11px]">GDPR Art-32:</span>
              <span className="text-emerald-700 font-bold">100% compliant</span>
            </div>
            <div className="bg-white p-2 rounded-lg flex items-center justify-between border border-slate-200">
              <span className="text-slate-500 font-mono text-[11px]">HIPAA Rule:</span>
              <span className="text-amber-700 font-bold">Audit block</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. DAST Logs Review & Code Remediation details */}
      <div className="lg:col-span-7 flex flex-col justify-between">
        {activeVul ? (
          <div className="bg-slate-950 rounded-2xl border border-slate-900 overflow-hidden flex flex-col h-full min-h-[460px] justify-between shadow-lg">
            {/* Review Title */}
            <div>
              <div className="bg-slate-900 px-5 py-3 border-b border-slate-900 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Selected Scan Log Review</span>
                  <h4 className="text-xs font-bold text-white mt-0.5">{activeVul.title}</h4>
                </div>

                {activeVul.status !== 'Remediated' && (
                  <button
                    onClick={() => onApplyRemediation(activeVul.id)}
                    disabled={isRemediating === activeVul.id}
                    className="px-3 py-1.5 rounded-lg text-xs font-mono font-bold text-white bg-rose-600 hover:bg-rose-500 shadow-sm shadow-rose-900/20 transition-all flex items-center gap-1.5"
                  >
                    {isRemediating === activeVul.id ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Fixing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" /> Remediate with AI
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Explaining information block */}
              <div className="p-5 space-y-4 text-slate-200">
                <div className="grid grid-cols-2 gap-4 bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs text-sans">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 block">Exposed By Analyzer Tool:</span>
                    <span className="text-slate-300 font-medium">{activeVul.toolExposedBy}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 block">System Vulnerability Class:</span>
                    <span className="text-slate-300 font-semibold">{activeVul.vulnerabilityClass}</span>
                  </div>
                </div>

                {/* Specific code block code fixed */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-300 uppercase block font-mono flex items-center gap-1">
                    <FileCode className="w-3.5 h-3.5 text-slate-400" /> Source parameter remediation fixes
                  </span>

                  <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl font-mono text-xs text-slate-200 overflow-y-auto max-h-[220px]">
                    <pre><code>{activeVul.remediationCode}</code></pre>
                  </div>
                </div>
              </div>
            </div>

            {/* Compliance badges footer labels */}
            <div className="bg-slate-900 p-4 border-t border-slate-900 flex items-center justify-between text-xs font-mono text-slate-400">
              <span>Target compliance standards:</span>
              <div className="flex gap-1.5">
                {activeVul.complianceLabels.map(lbl => (
                  <span key={lbl} className="bg-slate-850 border border-slate-800 text-indigo-400 px-2.5 py-0.5 rounded text-[10px] font-bold">
                    {lbl}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full min-h-[460px] rounded-2xl bg-white border border-slate-200 flex flex-col items-center justify-center text-center p-8 shadow-sm">
            <ShieldCheck className="w-12 h-12 text-slate-300 mb-2" />
            <span className="text-sm font-semibold text-slate-500">No scanned vulnerabilities identified</span>
          </div>
        )}
      </div>
    </div>
  );
}
