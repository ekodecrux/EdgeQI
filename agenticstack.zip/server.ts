import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini API safely to prevent startup crashes when API key is missing
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
  }
  return aiClient;
}

// Memory database for requirements and generated test data
interface ReqDb {
  requirements: any[];
  testCases: any[];
  defectHotspots: any[];
  impactReports: any[];
  scripts: any[];
  performanceConfigs: any[];
  securityVulnerabilities: any[];
  ragDocuments: any[];
  auditLogs: any[];
}

const db: ReqDb = {
  requirements: [
    {
      id: "REQ-101",
      projectId: "PROJ-STRI",
      title: "Secure Checkout Payment Gateway",
      content: "Ensure the billing module safely validates billing addresses, encrypts credit card numbers in transit via TLS 1.3, applies stripe API validation, and displays standard secure checkout UI matching bank requirements. Must handle negative edge conditions like empty names, invalid CVV numbers, card expiration dates, and network timeout rates.",
      sourceType: "text",
      parsedAt: new Date().toISOString(),
      suggestedModules: ["Billing", "Security", "Forms", "Integrations"],
    },
    {
      id: "REQ-102",
      projectId: "PROJ-CHAT",
      title: "Real-time Chat Notification Server",
      content: "Implement low-latency live chat delivery services across a WebSocket transport. System must correctly push message triggers, support offline persistence, and auto-fallback to HTTP long-polling if ports are blocked. Messages should render dynamically in responsive UI columns.",
      sourceType: "text",
      parsedAt: new Date().toISOString(),
      suggestedModules: ["Core WebSockets", "Databases", "Notifications"],
    },
    {
      id: "REQ-103",
      projectId: "PROJ-CRM",
      title: "SAP CRM Lead and Contract Automation",
      content: "Automator must verify that sales contracting sheets synchronize lead records to SAP Cloud CRM SOAP nodes on checkout completion. Must pierces Sales Cloud LWC Shadow DOM layers, support dynamic frame alignment, and stabilize data transmission handshakes.",
      sourceType: "text",
      parsedAt: new Date().toISOString(),
      suggestedModules: ["Integrations", "Shadow DOM", "Enterprise Bridge"],
    }
  ],
  testCases: [
    {
      id: "TC-001",
      projectId: "PROJ-STRI",
      title: "Successful Credit Card Validation and Charge",
      description: "Verifies checkout functions flawlessly when all fields are valid with valid stripe test accounts. Checks that secure authorization triggers proper TLS 1.3 encryption handshakes in transit.",
      preconditions: "User is authenticated and has selected products in checkout basket. Wallet system is online.",
      steps: [
        { action: "Navigate to the billing checkout route and fill in billing address fields.", expectedResult: "Form inputs match validation rules; no error warnings are displayed." },
        { action: "Enter valid test credit card details: 4242 4242 4242 (Expiry 12/28, CVV 323).", expectedResult: "Card input fields show valid format; submit button changes to active style." },
        { action: "Submit payment transaction authorization.", expectedResult: "Receipt page displays order confirmation matching order transaction code with charge receipt logged." }
      ],
      testData: "Card: 4242 4242 4242 4242, CVV: 323, Expiry: 12/28, Name: Alice Jones, Address: 100 Main St, SF, CA",
      priority: "P0",
      type: "Positive",
      automationStatus: "Automatable",
      confidenceScore: 98
    },
    {
      id: "TC-002",
      projectId: "PROJ-STRI",
      title: "Checkout Error State for Incomplete CVV Details",
      description: "Verifies immediate browser error validations for partial or invalid CVV integer bounds. Prevents submission to Stripe API to reduce network exceptions.",
      preconditions: "User cart holds at least one active product line on the Billing Screen.",
      steps: [
        { action: "Enter card name, expiration date, valid card number, and a single numerical digit in CVV block.", expectedResult: "Inline card code validator highlights field immediately with deep red border layout." },
        { action: "Assert validation exception message is visible.", expectedResult: "Feedback label displays 'CVV must be 3-4 digits long' and Submit Button is disabled." }
      ],
      testData: "Card: 4242 4242 4242 4242, CVV: 8, Expiry: 12/28, Name: Alice Jones",
      priority: "P1",
      type: "Negative",
      automationStatus: "Automatable",
      confidenceScore: 95
    },
    {
      id: "TC-003",
      projectId: "PROJ-CHAT",
      title: "WebSocket Connection State Handshake and Messaging Flow",
      description: "Verifies browser clients can initiate full secure socket upgrades successfully and post interactive message frames.",
      preconditions: "Chat WebSocket cluster cluster-a is in normal healthy active condition.",
      steps: [
        { action: "Load main Chat workspace UI page.", expectedResult: "System initializes Socket handshake upgrade header request." },
        { action: "Validate WS transmission upgrade response.", expectedResult: "Returns TCP Status 101 Switching Protocols. Network panel shows active ws channel." },
        { action: "Send message text frame 'Hello Agentic Queue'.", expectedResult: "Message is instantly broadcasted to recipient list; visual message bubbles update instantly." }
      ],
      testData: "WS URL: wss://chat.agency.local/live-mesh, Channel: Lobby-Room-4",
      priority: "P0",
      type: "Positive",
      automationStatus: "Automatable",
      confidenceScore: 96
    },
    {
      id: "TC-004",
      projectId: "PROJ-CHAT",
      title: "Fallback of Socket Server to HTTP Long-Polling",
      description: "Verifies chat client switches cleanly to long-polling transport fallback when socket ports are actively blocked by deep firewall layers.",
      preconditions: "User is connected behind simulated restrictive network boundaries.",
      steps: [
        { action: "Force block outgoing TCP WebSocket upgrade traffic.", expectedResult: "Socket connect attempts timeout or fail with connection refused state." },
        { action: "Await fallback interval mechanism (800ms).", expectedResult: "Client falls back automatically to HTTP long polling engine without UI rendering flickering." }
      ],
      testData: "REST FALLBACK: https://chat.agency.local/polling/fallback",
      priority: "P1",
      type: "Boundary",
      automationStatus: "Automatable",
      confidenceScore: 92
    },
    {
      id: "TC-005",
      projectId: "PROJ-CRM",
      title: "SAP CRM Lead Sales Sync Validation",
      description: "Verifies customer lead and contracting metadata synchronizes accurately in active CRM cloud ledgers and parses complex nested Shadow DOM UI boundaries.",
      preconditions: "Enterprise SAP and Sales Ledger APIs are authenticated in sandbox mode.",
      steps: [
        { action: "Enter lead credentials inside SAP frame controller overlay.", expectedResult: "Custom inputs parse criteria and pass outline constraints successfully." },
        { action: "Commit contract checkout actions.", expectedResult: "Triggers Salesforce Sales Cloud Sync callback. Leads ledger updates state code to 'active'." }
      ],
      testData: "SAP ID: CRM-84192, Contact: info@enterprise.com, Channel: CRM-Salesforce-LWC",
      priority: "P0",
      type: "Positive",
      automationStatus: "Automatable",
      confidenceScore: 94
    },
    {
      id: "TC-006",
      projectId: "PROJ-CRM",
      title: "SAP Timeout Recovery During Schema Outage",
      description: "Verifies systems recover logs gracefully if enterprise ERP adapters timeout under severe connection delays.",
      preconditions: "SAP CRM ERP backend adapter latency simulation set to 8000ms delay.",
      steps: [
        { action: "Post lead synchronization data packages.", expectedResult: "API pipeline handshakes wait for recovery boundaries." },
        { action: "Assert graceful timeout error callback (>= 5000ms).", expectedResult: "Saves record in transaction offline database. Returns user warning code 'SYNC_DELAYED_RETRY'." }
      ],
      testData: "Delay: 8000ms, Sync Limit: 5000ms",
      priority: "P2",
      type: "Negative",
      automationStatus: "Needs Manual",
      confidenceScore: 88
    }
  ],
  defectHotspots: [
    {
      projectId: "PROJ-STRI",
      moduleName: "Billing & Card Encryption",
      historicalDefectsCount: 14,
      predictedRiskScore: 88,
      commonFailureType: "TLS handshake timing, cryptographic padding errors",
      developerPattern: "Frequent billing updates by junior developers",
      recommendation: "Focus extensive stress tests on payment token handshakes and edge input bounds."
    },
    {
      projectId: "PROJ-CHAT",
      moduleName: "WebSocket Server Thread Pools",
      historicalDefectsCount: 8,
      predictedRiskScore: 72,
      commonFailureType: "Memory leaks during concurrent socket drops",
      developerPattern: "Infrequent connection handshakes configuration overrides",
      recommendation: "Conduct API k6 performance test loading 500 concurrent users over 3 minutes."
    },
    {
      projectId: "PROJ-CRM",
      moduleName: "SAP ERP Ledger CRM Connection Bridge",
      historicalDefectsCount: 5,
      predictedRiskScore: 61,
      commonFailureType: "Dynamic iframe DOM piercing timeout on checkout syncs",
      developerPattern: "Custom sales pipeline integration schemas",
      recommendation: "Stabilize shadow root connectors using playwrites standard deep selectors."
    }
  ],
  impactReports: [
    {
      changeTrigger: "Update Stripe API Version to 2024-Q2",
      impactedModule: "Billing & Card Encryption",
      riskScore: 84,
      impactedTestCaseIds: ["TC-001", "TC-002"],
      traceabilityMatrix: {
        "Billing API Connectors": ["TC-001"],
        "Payment Validation UI": ["TC-002"]
      }
    }
  ],
  scripts: [
    {
      fileName: "checkout_billing.spec.ts",
      framework: "Playwright",
      language: "TypeScript",
      code: `import { test, expect } from '@playwright/test';\n\ntest.describe('Payment Gateway checkout tests', () => {\n  test('TC-001: Valid Checkout Submission Flow', async ({ page }) => {\n    // Go to billing route\n    await page.goto('/checkout/billing');\n    \n    // Enter card details with realistic waits\n    await page.fill('[data-testid=\"card-number\"]', '4242424242424242');\n    await page.fill('[data-testid=\"card-cvv\"]', '242');\n    await page.fill('[data-testid=\"card-expiry\"]', '12/28');\n    await page.fill('[data-testid=\"card-name\"]', 'Alice Jones');\n    \n    // Click secure submit\n    await page.click('#btn-submit-secure-checkout');\n    \n    // Validate success modal\n    const confirmText = page.locator('.payment-success-msg');\n    await expect(confirmText).toBeVisible({ timeout: 10000 });\n    await expect(confirmText).toContainText('Payment authorized successfully');\n  });\n});`
    }
  ],
  performanceConfigs: [
    {
      testType: "API",
      endpointOrJourney: "POST /api/v1/checkout/charge",
      virtualUsers: 250,
      durationSeconds: 60,
      rampUpTimeSeconds: 10,
      rpsLimit: 100,
      metrics: {
        avgResponseTimeMs: 142,
        p90Ms: 230,
        p95Ms: 298,
        p99Ms: 460,
        throughputTps: 84.5,
        errorRate: 0.12,
        cpuUtilization: 42,
        memoryUtilization: 68
      },
      aiRecommendations: [
        "Database pool size limit reached during checkout transactions. Increase pg connection count to 150.",
        "Add Redis cache index on Stripe country lookup metadata to shave 30ms from transit time."
      ]
    }
  ],
  securityVulnerabilities: [
    {
      id: "SEC-001",
      projectId: "PROJ-STRI",
      title: "Improper SQL Input Parameter Escaping in Payment Logs",
      type: "SAST",
      severity: "Critical",
      toolExposedBy: "SonarQube & Snyk Client Analyzers",
      vulnerabilityClass: "OWASP-01: Injection",
      remediationCode: `// INCORRECT:\nconst query = "SELECT * FROM charges WHERE trace_id = '" + req.query.id + "'";\n\n// FIXED REMEDIATION:\nconst query = "SELECT * FROM charges WHERE trace_id = $1";\nawait db.query(query, [req.query.id]);`,
      complianceLabels: ["PCI-DSS", "SOC2"],
      status: "Open"
    },
    {
      id: "SEC-002",
      projectId: "PROJ-CHAT",
      title: "Broken Encryption Algorithm fallback in cookie parser",
      type: "SCA",
      severity: "High",
      toolExposedBy: "Trivy Dependency Scanner",
      vulnerabilityClass: "OWASP-02: Cryptographic Failures",
      remediationCode: `// INCORRECT:\nconst crypto = require('crypto');\nconst cipher = crypto.createCipher('aes-128-cbc', key);\n\n// FIXED REMEDIATION:\nconst cipher = crypto.createCipheriv('aes-256-gcm', key, iv);`,
      complianceLabels: ["GDPR", "HIPAA"],
      status: "Open"
    }
  ],
  ragDocuments: [
    {
      id: "DOC-01",
      name: "payment_security_guidelines_v4.pdf",
      size: "2.4 MB",
      type: "PDF",
      ingestedAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
      chunksCount: 165,
      status: "Ingested"
    }
  ],
  auditLogs: [
    {
      id: "AUD-001",
      timestamp: new Date().toISOString(),
      userEmail: "parimi.prasad@gmail.com",
      action: "Platform Initialized",
      affectedEntity: "Core Orchestrator",
      details: "Quality Engineering Platform core systems loaded on Port 3000."
    }
  ]
};

// Log generic actions globally
function addAudit(action: string, entity: string, details: string, latencyMs?: number, cost?: number) {
  db.auditLogs.unshift({
    id: `AUD-${Math.floor(Date.now() / 1000).toString().slice(-6)}`,
    timestamp: new Date().toISOString(),
    userEmail: "parimi.prasad@gmail.com",
    action,
    affectedEntity: entity,
    details,
    latencyMs,
    costEstimate: cost || 0.002
  });
}

// 1. CORE CHATBOT ROUTE (using @google/genai SDK)
app.post("/api/quality/assistant/chat", async (req, res) => {
  const { prompt, history } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: "No prompt supplied." });
  }

  const ai = getGeminiClient();
  const start = Date.now();

  if (ai) {
    try {
      // Setup chats
      const systemPrompt = "You are the premium technical lead of the Agentic AI Quality Intelligence Platform. You help QA engineers configure, test, automate, heal, run performance benchmarks, and evaluate compliance security. Answer concisely in elegant markdown with accurate examples.";
      const contents = [];
      if (history && Array.isArray(history)) {
        history.slice(-6).forEach(h => {
          contents.push({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.content }] });
        });
      }
      contents.push({ role: 'user', parts: [{ text: prompt }] });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.3
        }
      });
      const responseText = response.text || "I was unable to complete the generation request. No content yielded.";
      addAudit("Assistant Query", "Agent Assistant", `Query: "${prompt.slice(0, 40)}..."`, Date.now() - start);
      return res.json({ text: responseText });
    } catch (e: any) {
      console.error("Gemini Assistant error:", e);
      addAudit("Assistant Query (Fallback)", "Agent Assistant", `API Error: ${e.message}`, Date.now() - start);
    }
  }

  // Fallback beautiful chat responses based on matching keywords
  let reply = "I am ready to assist you. Ask me about test generation, locator strategies, performance metrics, self-healing thresholds, or cybersecurity reports.";
  const lowered = prompt.toLowerCase();
  if (lowered.includes("generate") || lowered.includes("test case")) {
    reply = "### Automated Test Generation Blueprint\nI can read requirements in text, PDF, markdown or via APIs and auto-generate exhaustive test scenarios. \n\nWe provide:\n- **P0-P3 Priority mapping** based on predicted user engagement.\n- **Positive, Negative & Interactive Edge conditions**.\n- **Locators estimation** mapped accurately for Selenium and Playwright.";
  } else if (lowered.includes("heal") || lowered.includes("locator")) {
    reply = "### Agentic Self-Healing Engine\nOur self-healing loops auto-heal broken locators by crawling active DOM structures:\n1. **Dynamic search matches**: uses fallback AI-driven tags.\n2. **Visual alignment mapping**: checks coordinates and surrounding DOM element labels.\n3. **History logging**: records heals to maintain a high-confidence index.";
  } else if (lowered.includes("security") || lowered.includes("sast")) {
    reply = "### Security Remediation Pipeline\nI evaluate codebases against **OWASP Top 10 vulnerabilities**:\n- **SAST Checkers** scanning syntax imports.\n- **SCA dependency watch** alerting of outdated module patches.\n- **AI code recommendations** with direct CJS/ESM fixes to click and deploy.";
  } else if (lowered.includes("perf") || lowered.includes("performance") || lowered.includes("load")) {
    reply = "### High-Scale Load Injector\nTo trigger a performance loop:\n- Specify **Virtual Users (VUs)** up to 100,000+.\n- Set ramp-up sequences, pacing rules and target RPS thresholds.\n- We render real-time response plots for quick diagnostic drill-downs.";
  }

  const simulatedLatency = 600;
  setTimeout(() => {
    addAudit("Assistant Query (Mocked)", "Agent Assistant", `Query: "${prompt.slice(0, 40)}..."`, simulatedLatency);
    res.json({ text: reply + "\n\n*(Self-healing fallback state active; configure a valid process.env.GEMINI_API_KEY in secrets to enable active real-time model completions)*" });
  }, simulatedLatency);
});

// 2. FILE AND DOCUMENT INGESTION (RAG)
app.get("/api/quality/rag/documents", (req, res) => {
  res.json(db.ragDocuments);
});

app.post("/api/quality/rag/upload", (req, res) => {
  const { name, textContent } = req.body;
  const newDoc = {
    id: `DOC-${Math.floor(Date.now() / 1000).toString().slice(-4)}`,
    name: name || "requirements_doc_manual.txt",
    size: textContent ? `${(Buffer.byteLength(textContent) / 1024).toFixed(1)} KB` : "120 KB",
    type: name?.split('.')?.pop()?.toUpperCase() || "TEXT",
    ingestedAt: new Date().toISOString(),
    chunksCount: Math.max(1, Math.floor((textContent?.length || 500) / 150)),
    status: "Ingested" as const
  };
  db.ragDocuments.unshift(newDoc);
  addAudit("RAG Ingestion", "Knowledge Database", `Uploaded document: "${newDoc.name}"`, 150);
  res.json({ success: true, doc: newDoc });
});

// 3. REQUIREMENTS PARSING AND TEST CASE GENERATION
app.get("/api/quality/requirements", (req, res) => {
  res.json(db.requirements);
});

app.get("/api/quality/testcases", (req, res) => {
  res.json(db.testCases);
});

app.post("/api/quality/requirements/add", async (req, res) => {
  const { title, content, sourceType, projectId, crawlerSettings } = req.body;
  if (!content) {
    return res.status(400).json({ error: "Missing requirement content or URL path." });
  }

  const start = Date.now();
  let finalTitle = title || `Discovered Target on ${content}`;
  let finalContent = content;
  let finalModulesList = ["Core", "GeneralUI"];

  if (sourceType === 'url') {
    const isSap = crawlerSettings?.sapGuiWeb || content.toLowerCase().includes("sap") || finalTitle.toLowerCase().includes("sap");
    const isSalesforce = crawlerSettings?.salesforceShadow || content.toLowerCase().includes("salesforce") || finalTitle.toLowerCase().includes("salesforce") || content.toLowerCase().includes("servicenow");
    
    finalTitle = isSap 
      ? `Live Discovered SAP ECC / ERP UI Screen Flows - ${content.replace(/^https?:\/\//, '').split('/')[0]}` 
      : isSalesforce
        ? `Live Salesforce/ServiceNow Target Core UI Views - ${content.replace(/^https?:\/\//, '').split('/')[0]}`
        : `Live Discovered UI Screen Flows - ${content.replace(/^https?:\/\//, '').split('/')[0]}`;

    finalContent = `Automated crawl profile generated for ${content}. Enabled adapters: ${crawlerSettings?.sapGuiWeb ? 'SAP Web GUI dynamic adapters, ' : ''}${crawlerSettings?.salesforceShadow ? 'Salesforce Shadow-DOM Deep Pierce adapter, ' : ''}Standard browser parser. Security state: Auth credentials supplied for user: '${crawlerSettings?.username || 'anonymous'}'. Discovery completed successfully: mapped corresponding DOM frames, text grids, and dynamic routes.`;
    finalModulesList = isSap ? ["SAP-ERP", "System-GUI"] : isSalesforce ? ["Salesforce-CRM", "LWC-Core"] : ["Discovery", "GeneralUI"];
  }

  const pid = projectId || (finalTitle.toLowerCase().includes("chat") || finalContent.toLowerCase().includes("socket") ? "PROJ-CHAT" : (finalTitle.toLowerCase().includes("sap") || finalContent.toLowerCase().includes("crm") ? "PROJ-CRM" : "PROJ-STRI"));

  const newReq = {
    id: `REQ-${Math.floor(Date.now() / 1000).toString().slice(-3)}`,
    projectId: pid,
    title: finalTitle,
    content: finalContent,
    sourceType: sourceType || "text",
    parsedAt: new Date().toISOString(),
    suggestedModules: finalModulesList
  };

  db.requirements.unshift(newReq);

  // Default Fallback code generated - Extremely Detailed, SAP & COTS Optimized!
  let generatedTCs = [];

  const isSapActive = crawlerSettings?.sapGuiWeb || finalTitle.includes("SAP") || finalContent.includes("SAP");
  const isSalesforceActive = crawlerSettings?.salesforceShadow || finalTitle.includes("Salesforce") || finalContent.includes("Salesforce") || finalContent.includes("ServiceNow");

  if (isSapActive) {
    generatedTCs = [
      {
        id: `TC-SAP-${Math.floor(Math.random() * 800) + 200}`,
        projectId: pid,
        requirementId: newReq.id,
        title: "Verify SAP WebGUI Dynamic Frame Attachment and Transaction VA01 Navigation",
        description: "Verify that the Playwright test engine dynamically attaches to the correct SAP inner frame, inputs Tx VA01 (Create Sales Order), and captures the table grid element.",
        preconditions: "User is authenticated. SAP ecc backend GUI ITS gateway is fully online and responsive.",
        steps: [
          { action: "Await the parent frame stabilizer to load, then select the SAP dynamic iframe.", expectedResult: "SAP frame attachments resolved successfully, nested frame DOM attached." },
          { action: "Execute SAP locator inputs: transaction command 'VA01' inside command input box.", expectedResult: "Form refresh completes, VA01 Sales Order input viewport renders." },
          { action: "Input billing coordinates, sales organization '1000' and distribution channel '10'.", expectedResult: "Dynamic table fields load and permit editing." }
        ],
        testData: `{"sapUser": "${crawlerSettings?.username || 'sap_tester'}", "commandText": "VA01", "salesOrg": "1000", "sapFrameId": "urFrame_1"}`,
        priority: "P0",
        type: "Positive",
        automationStatus: "Automated",
        confidenceScore: 98
      },
      {
        id: `TC-SAP-${Math.floor(Math.random() * 800) + 300}`,
        projectId: pid,
        requirementId: newReq.id,
        title: "Verify SAP Data Grid Integrity and Transaction VA02 Commit states",
        description: "Ensures edited row elements in SAP main control grid do not get scrambled on dynamic session timeout triggers.",
        preconditions: "SAP dynamic VA02 page view is active with historical sales coordinates populated.",
        steps: [
          { action: "Inject dynamic cell values directly via Playwright cell-force hook.", expectedResult: "Values committed, SAP dynamic total recalculates safely." },
          { action: "Click 'SAVE' command shortcut and verify browser status feedback.", expectedResult: "SAP system message 'Sales Document 12848 Saved' appears in status area." }
        ],
        testData: "Transaction = VA02, OrderId = 12848, gridCellIndex = 4",
        priority: "P1",
        type: "Boundary",
        automationStatus: "Automatable",
        confidenceScore: 94
      }
    ];
  } else if (isSalesforceActive) {
    generatedTCs = [
      {
        id: `TC-SF-${Math.floor(Math.random() * 800) + 200}`,
        projectId: pid,
        requirementId: newReq.id,
        title: "Verify Salesforce LWC Shadow DOM Deep Pierce Locator Resolution",
        description: "Assert that the Deep Pierce CSS selectors successfully penetrate closed Shadow-roots inside Lightning CRM custom dashboards.",
        preconditions: "Lightning web console layout initialized. Dashboard modules exist.",
        steps: [
          { action: "Query search target element using deep piercing locator '>>> c-lwc-dashboard' or dynamic Playwright shadow locator.", expectedResult: "Target dashboard returns HTML DOM node container." },
          { action: "Fill in custom customer account information on the dynamic search card.", expectedResult: "Lightning data store filters matches, displays matched CRM record." }
        ],
        testData: `{"crmUser": "${crawlerSettings?.username || 'sales_user'}", "deepPiercePattern": ">>> .form-element-input", "accountName": "Acme Corp"}`,
        priority: "P0",
        type: "Positive",
        automationStatus: "Automated",
        confidenceScore: 96
      }
    ];
  } else {
    // Standard Discovery test suite
    generatedTCs = [
      {
        id: `TC-${Math.floor(Math.random() * 800) + 200}`,
        projectId: pid,
        requirementId: newReq.id,
        title: `Verify ${finalTitle} fundamental positive scenario with valid inputs`,
        description: `Test normal operation sequence of "${finalTitle}". Asserts system accepts structured parameters and logs details in trace logs safely with high compliance.`,
        preconditions: `Platform services are fully active. Database connections are synchronized.`,
        steps: [
          { action: "Configure test environment variables with realistic default properties.", expectedResult: "Test config registers settings; no security or integrity alarms trigger." },
          { action: "Trigger standard functional submission action with healthy request body payload.", expectedResult: "System processes sync event immediately. HTTP Status 200 OK returned." },
          { action: "Verify state values are committed correctly in the primary backend database.", expectedResult: "Audit table appends a new state node; visual layout updates seamlessly." }
        ],
        testData: `{"targetEnv": "sandbox", "requestUser": "${crawlerSettings?.username || 'qa-master@agency.local'}", "payloadType": "JSON", "title": "${finalTitle}"}`,
        priority: "P0",
        type: "Positive",
        automationStatus: "Automatable",
        confidenceScore: 94
      },
      {
        id: `TC-${Math.floor(Math.random() * 800) + 300}`,
        projectId: pid,
        requirementId: newReq.id,
        title: `Verify ${finalTitle} error feedback under invalid empty metadata fields`,
        description: `Verifies negative schema constraints. Validates that the systems reject incomplete payloads and show clear user-facing guidelines without revealing system internals.`,
        preconditions: "Authentication token is active; input bounds is set to null parameters.",
        steps: [
          { action: "Submit query with all standard schema parameters passed empty or null.", expectedResult: "Validation core catches exceptions instantly; returns error reference." },
          { action: "Assert descriptive warning notification layout exists.", expectedResult: "Interface displays clear 'Missing required fields' message without crashing backend servers." }
        ],
        testData: "Payload fields = NULL, Token = Active, Mode = BoundaryTesting",
        priority: "P1",
        type: "Negative",
        automationStatus: "Automatable",
        confidenceScore: 91
      }
    ];
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      const prompt = `Analyze this ${sourceType === 'url' ? 'Live Web Crawled Application Discovery metadata' : 'project requirement'} and generate exactly three extremely detailed and distinct test cases in strict JSON schema.
      ${sourceType === 'url' ? 'Discovered URL Target: ' + content : 'Requirement Title: ' + finalTitle}
      Description of state: ${finalContent}
      Adapters Specified: ${JSON.stringify(crawlerSettings || {})}

      Return only a JSON array matching this interface:
      TestCase[] where interfaces are:
      interface TestCase {
        id: string; // generate random 3 digit id like 'TC-481'
        projectId: string; // MUST be exactly matching "${pid}"
        requirementId: string; // MUST be exactly matching "${newReq.id}"
        title: string; // clear, detailed functional title. If SAP/Salesforce was specified, customize steps to include dynamic frames, VA01 / Lightning elements or Shadow DOM pierce parameters.
        description: string; // thorough description of test goals, assertions, and boundary checks
        preconditions: string; // explicit system pre-requisites
        steps: { action: string; expectedResult: string }[]; // generate 3 to 5 detailed, distinct steps
        testData: string; // rich realistic test data (parameters, headers, tokens, or mock objects)
        priority: 'P0' | 'P1' | 'P2' | 'P3';
        type: 'Positive' | 'Negative' | 'Edge' | 'Boundary';
        automationStatus: 'Automated' | 'Needs Manual' | 'Automatable';
        confidenceScore: number; // integer 0 to 100
      }
      
      Output absolutely nothing else but valid raw JSON syntax. Clear markdown wrappers.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2
        }
      });

      const responseText = response.text || "";
      const cleaned = responseText.replace(/```json/g, "").replace(/```/g, "").trim();
      const parsedArray = JSON.parse(cleaned);
      if (Array.isArray(parsedArray)) {
        // Enforce projectId and requirementId correctly
        generatedTCs = parsedArray.map(tc => ({ 
          ...tc, 
          projectId: pid,
          requirementId: newReq.id,
          automationStatus: tc.automationStatus || "Automatable"
        }));
      }
    } catch (err: any) {
      console.warn("Could not generate using Gemini API on requirements. Using smart fallbacks instead. Error:", err.message);
    }
  }

  // Prepend to our memory database
  generatedTCs.forEach(tc => {
    db.testCases.unshift(tc);
  });

  // Calculate generic modules suggestions
  if (finalTitle.toLowerCase().includes("payment") || finalTitle.toLowerCase().includes("billing")) {
    newReq.suggestedModules = ["Billing", "Security", "Forms"];
  } else if (finalTitle.toLowerCase().includes("chat") || finalTitle.toLowerCase().includes("web")) {
    newReq.suggestedModules = ["WebSocket", "Messaging", "Socket Gateway"];
  }

  addAudit("Parse Requirement", "Requirements Agent", `Parsed: "${finalTitle}" inside Project ${pid} (Type: ${sourceType})`, Date.now() - start);
  res.json({ success: true, requirement: newReq, generatedTestCases: generatedTCs });
});

// 4. DEFECT PATTERN ANALYSIS & PREDICTIONS
app.get("/api/quality/defects/hotspots", (req, res) => {
  res.json(db.defectHotspots);
});

app.post("/api/quality/defects/predict", async (req, res) => {
  const { title, description } = req.body;
  const start = Date.now();
  let aiForecast = {
    riskScore: 68,
    failureType: "Race condition under persistent thread loops",
    recommendation: "Avoid loading concurrent memory tasks in loops without interval pacing."
  };

  const ai = getGeminiClient();
  if (ai) {
    try {
      const prompt = `Given a user requirement description: "${title}": "${description}". Analyze typical historical defects in such modules.
      Predict:
      1. What is the predicted risk percentage score (0 to 100)?
      2. What is the most expected failure type?
      3. What recommendation on focus testing should we apply?
      
      Respond directly in this exact JSON structure:
      {
        "riskScore": number,
        "failureType": "string",
        "recommendation": "string"
      }`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2
        }
      });
      const responseText = response.text || "";
      const parsed = JSON.parse(responseText.replace(/```json/g, "").replace(/```/g, "").trim());
      if (parsed && typeof parsed.riskScore === 'number') {
        aiForecast = parsed;
      }
    } catch (e) {
      console.warn("AI Defect forecasting exception. Using fallback simulation.");
    }
  }

  // Create a new hotspot entry in db for simulation visualization
  const newHotspot = {
    moduleName: title || "New Generated Target",
    historicalDefectsCount: Math.floor(Math.random() * 5),
    predictedRiskScore: aiForecast.riskScore,
    commonFailureType: aiForecast.failureType,
    developerPattern: "Dynamic layout integrations",
    recommendation: aiForecast.recommendation
  };
  db.defectHotspots.unshift(newHotspot);

  addAudit("Defect Analysis", "Predictive Analytics Agent", `Calculated risk for ${title}: ${aiForecast.riskScore}%`, Date.now() - start);
  res.json({ success: true, predicted: newHotspot });
});

// 5. IMPACT ANALYSIS & REGRESSION SELECTION
app.get("/api/quality/impact/reports", (req, res) => {
  res.json(db.impactReports);
});

app.post("/api/quality/impact/analyze", (req, res) => {
  const { changeTrigger, description } = req.body;
  if (!changeTrigger) {
    return res.status(400).json({ error: "No change trigger specified." });
  }

  const start = Date.now();
  // Find related testcases in system
  const testIds = db.testCases.map(tc => tc.id);
  const selectedTCs = testIds.slice(0, Math.min(testIds.length, 3));
  const risk = Math.floor(Math.random() * 41) + 45; // 45 - 85

  const newReport = {
    changeTrigger,
    impactedModule: "Web UI & Gateways",
    riskScore: risk,
    impactedTestCaseIds: selectedTCs,
    traceabilityMatrix: {
      "DOM selectors / components": selectedTCs
    }
  };

  db.impactReports.unshift(newReport);
  addAudit("Impact Analysis", "Impact Analyzer Agent", `Triggered code analysis for: "${changeTrigger}"`, Date.now() - start);
  res.json({ success: true, report: newReport });
});

// 6. MULTI-FRAMEWORK SCRIPT GENERATION
app.get("/api/quality/scripts", (req, res) => {
  res.json(db.scripts);
});

app.post("/api/quality/scripts/generate", async (req, res) => {
  const { testCaseId, framework, language } = req.body;
  const start = Date.now();

  const testCase = db.testCases.find(tc => tc.id === testCaseId) || db.testCases[0];
  const targetFramework = framework || "Playwright";
  const targetLang = language || "TypeScript";

  let scriptCode = `// Generated AI code for ${testCase.id}: ${testCase.title}\n`;
  if (targetFramework === "Playwright") {
    scriptCode += `import { test, expect } from '@playwright/test';\n\ntest('${testCase.id}: ${testCase.title}', async ({ page }) => {\n  // Preconditions: ${testCase.preconditions}\n`;
    testCase.steps.forEach((step: any, idx: number) => {
      scriptCode += `  // Step ${idx + 1}: ${step.action}\n  // Expectation: ${step.expectedResult}\n`;
    });
    scriptCode += `});`;
  } else if (targetFramework === "Cypress") {
    scriptCode += `describe('${testCase.title}', () => {\n  it('Executes ${testCase.id}', () => {\n    // Preconditions: ${testCase.preconditions}\n`;
    testCase.steps.forEach((step: any, idx: number) => {
      scriptCode += `    cy.log('Action: ${step.action}');\n`;
    });
    scriptCode += `  });\n});`;
  } else {
    scriptCode += `# Simulated Automation script using Python & Selenium for ${testCase.title}\nimport unittest\n`;
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      const prompt = `Write a high-quality automation test script using ${targetFramework} with ${targetLang} language.
      
      Test Case Context:
      ID: ${testCase.id}
      Title: ${testCase.title}
      Description: ${testCase.description}
      Preconditions: ${testCase.preconditions}
      Steps & Expected Results:
      ${JSON.stringify(testCase.steps, null, 2)}
      Test Data Input: ${testCase.testData}

      The code should:
      - Adhere to the Page Object Model (POM) pattern or clean code standards.
      - Use proper retry awaits (explicit waits) and handles dynamic DOM properties gracefully.
      - Be fully formatted with imports. Ensure no conversational markdown text surrounds the code block — just the raw script contents inside standard markdown code indicators.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          temperature: 0.1
        }
      });
      const text = response.text || "";
      const matches = text.match(/```(?:javascript|typescript|python|java|type|js)?\n([\s\S]+?)\n```/);
      if (matches && matches[1]) {
        scriptCode = matches[1];
      } else {
        scriptCode = text;
      }
    } catch (e: any) {
      console.warn("Exception writing automated code with Gemini model. Loading simulator template.", e.message);
    }
  }

  const newScript = {
    fileName: `${testCase.title.toLowerCase().replace(/[^a-z0-9]/g, '_')}.spec.ts`,
    framework: targetFramework,
    language: targetLang,
    code: scriptCode
  };

  // Replace or push
  const existingIdx = db.scripts.findIndex(s => s.fileName === newScript.fileName);
  if (existingIdx >= 0) {
    db.scripts[existingIdx] = newScript;
  } else {
    db.scripts.unshift(newScript);
  }

  addAudit("Script Generation", "Script Automation Agent", `Compiled ${targetFramework} POM Code for ${testCase.id}`, Date.now() - start);
  res.json({ success: true, script: newScript });
});

// 6b. ENTERPRISE CO-TRANSPILER & SAP BRIDGE ADAPTERS
app.post("/api/quality/scripts/convert", async (req, res) => {
  const { 
    sourceCode, 
    sourceFramework, 
    sourceLang, 
    targetFramework, 
    targetLang,
    sapGuiWeb,
    salesforceShadow,
    servicenowFrames,
    visualAiCoord
  } = req.body;

  const start = Date.now();
  let convertedCode = "";
  let accuracy = 95;
  let locatorsConverted = 5;
  const modulesLoaded: string[] = [];

  const ai = getGeminiClient();
  if (ai) {
    try {
      const activeAddonsPrompt = [
        sapGuiWeb ? "- SAP Web GUI client adapters (handles dynamic controls, nested frame/iframe contexts like `#sap-iframe-layer` or `#ITS_EASY_WEB`)" : "",
        salesforceShadow ? "- Salesforce LWC Shadow DOM resolver (uses Playwright `>>>` combinators or Selenium script-pierces to access hidden ShadowDOM fields)" : "",
        servicenowFrames ? "- ServiceNow dynamic frame stabilizers (coordinates page, iframe switches, and modal panels smoothly)" : "",
        visualAiCoord ? "- Visual AI OCR coordinates matching (supports coordinate bounds clicks on untargeted Canvas/Graphics controls)" : ""
      ].filter(Boolean).join("\n");

      const prompt = `You are an expert automated testing script compiler and SAP/COTS automation bridge builder. Your task is to translate an end-to-end automation testing script from:
      Source Tool: ${sourceFramework}
      Source Language: ${sourceLang}
      
      To:
      Target Tool: ${targetFramework}
      Target Language: ${targetLang}
      
      In addition, you MUST integrate support for the following activated Enterprise/COTS App Add-ons to resolve dynamic control elements:
      ${activeAddonsPrompt || "- None requested."}
      
      Source Script Code:
      \`\`\`
      ${sourceCode}
      \`\`\`
      
      Generate a clean, completely valid automation test script.
      The output should:
      - Adhere to structured testing patterns (e.g. Page Object Models, clear E2E workflows).
      - Embed clear comments explaining where the dynamic COTS elements, custom frame switchers, or Shadow DOM deep selectors are applied.
      - Return ONLY the clean, formatted python / typescript / java code block. Do NOT surround the script block with any conversational comments — return the raw formatted code block.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          temperature: 0.1
        }
      });

      const responseText = response.text || "";
      const matches = responseText.match(/```(?:javascript|typescript|python|java|type|js|xml)?\n([\s\S]+?)\n```/);
      if (matches && matches[1]) {
        convertedCode = matches[1];
      } else {
        convertedCode = responseText.replace(/```/g, "").trim();
      }

      locatorsConverted = Math.floor(Math.random() * 5) + 6;
      if (sapGuiWeb) modulesLoaded.push("SAP Web GUI Adapter");
      if (salesforceShadow) modulesLoaded.push("Lightning Root Resolver");
      if (servicenowFrames) modulesLoaded.push("Frame Synchronizer");
      if (visualAiCoord) modulesLoaded.push("OCR Canvas Anchoring");

      addAudit("Script Conversion", "Script Automation Agent", `Translated script from ${sourceFramework} to ${targetFramework} using Gemini 3.5-flash`, Date.now() - start);
      return res.json({ 
        success: true, 
        convertedCode, 
        accuracy: 97, 
        locatorsConverted,
        modulesLoaded
      });
    } catch (e: any) {
      console.warn("Gemini Script Translation call failed, using heuristic fallback model:", e.message);
    }
  }

  // Backup fallback signal if API key is not configured or fails
  res.json({ success: false, error: "API key is missing or model invocation timeout." });
});

// 7. HIGH-SCALE PERFORMANCE TESTING SIMULATOR
app.get("/api/quality/performance/configs", (req, res) => {
  res.json(db.performanceConfigs);
});

app.post("/api/quality/performance/execute", (req, res) => {
  const { testType, endpointOrJourney, virtualUsers, durationSeconds, rampUpTimeSeconds, rpsLimit } = req.body;
  const start = Date.now();

  const config = {
    testType: testType || "API",
    endpointOrJourney: endpointOrJourney || "POST /api/payment/v1/charge",
    virtualUsers: Number(virtualUsers) || 100,
    durationSeconds: Number(durationSeconds) || 30,
    rampUpTimeSeconds: Number(rampUpTimeSeconds) || 5,
    rpsLimit: Number(rpsLimit) || 50,
    metrics: {
      avgResponseTimeMs: Math.floor(Math.random() * 80) + 110,
      p90Ms: Math.floor(Math.random() * 120) + 180,
      p95Ms: Math.floor(Math.random() * 150) + 210,
      p99Ms: Math.floor(Math.random() * 200) + 380,
      throughputTps: (Number(virtualUsers) * 0.42).toFixed(1),
      errorRate: Number(virtualUsers) > 800 ? 1.4 : 0.05,
      cpuUtilization: Math.floor(Math.random() * 20) + (Number(virtualUsers) > 500 ? 70 : 35),
      memoryUtilization: Math.floor(Math.random() * 15) + (Number(virtualUsers) > 500 ? 82 : 45)
    },
    aiRecommendations: [
      `Response p99 spiked during load injector peak scale. Recommended thread lock adjustments on server thread handlers.`,
      `Database connection pool size handles memory blocks elegantly. Maintain Current Index strategies.`
    ]
  };

  db.performanceConfigs.unshift(config);
  addAudit("Perf Execution", "Performance Scale Agent", `Ran load simulation on "${endpointOrJourney}" with ${virtualUsers} users.`, Date.now() - start);
  res.json({ success: true, config });
});

// 8. SECURITY REMEDIATION PIPELINE
app.get("/api/quality/security/vulnerabilities", (req, res) => {
  res.json(db.securityVulnerabilities);
});

app.post("/api/quality/security/remediate", async (req, res) => {
  const { vulnerabilityId } = req.body;
  const start = Date.now();

  const vul = db.securityVulnerabilities.find(v => v.id === vulnerabilityId);
  if (!vul) {
    return res.status(404).json({ error: "Vulnerability metadata target not logged." });
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      const prompt = `Review the security vulnerability: "${vul.title}" in class "${vul.vulnerabilityClass}".
      Provide highly secure Node.js or Javascript parameter remediation code to secure the application.
      Show both the insecure code block and the fully secured fixed code block nicely.
      Provide only the code and short comments.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          temperature: 0.1
        }
      });
      if (response.text) {
        vul.remediationCode = response.text;
      }
    } catch (e: any) {
      console.warn("Remediation prompt fallback due to missing client API. Error:", e.message);
    }
  }

  vul.status = "Remediated";
  addAudit("Security Fix Applied", "DevSecOps Security Agent", `Applied AI Parameter Remediation on ${vulnerabilityId}`, Date.now() - start);
  res.json({ success: true, vulnerability: vul });
});

// 9. AUDIT UTILITIES
app.get("/api/quality/audit", (req, res) => {
  res.json(db.auditLogs);
});

// Serve Vite middleware on top of the endpoints
async function startServer() {
  if (process.env.DISABLE_HMR === 'true') {
    // Force set NODE_ENV to production simulation to protect HMR triggers if requested
  }

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express server running on http://localhost:${PORT}`);
  });
}

startServer();
